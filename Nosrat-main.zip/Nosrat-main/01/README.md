> [!NOTE]
> ### درس اول آموزش زبان انگلیسی نصرت


> برای دریافت فایل صوتی [کلیک کنید](https://raw.githubusercontent.com/sahar-km/Nosrat/refs/heads/main/01/11.amr)


<br> 


******


hello  
سلام  


How are you?  
حالت چطوره؟  


fine  
خوب  


thanks  
ممنون  


yes  
بله  

no  
نه  

and  
و  

you  
تو  

from  
از  

from Iran  
از ایران  

Canada  
کانادا  

from Canada  
از کانادا  

I am.  
من هستم.  

I'm fine.  
حالم خوبه.  

I'm from Iran.  
من از ایران هستم.  

I'm not.  
من نیستم.  

You are.  
تو هستی.  

You're from Canada.  
تو از کانادا هستی.  

Are you?  
آیا تو هستی؟  

too  
هم  

I'm from Iran, too.  
من هم از ایران هستم.  


*****  

A: Hello.  
A: سلام.  

<br>

B: Hello.  
B: سلام.  

<br>

A: How are you?  
A: حالت چطوره؟  

<br>

B: I'm fine, thanks.  
B: حالم خوبه، ممنون.  

<br>

A: Are you from Iran?  
A: آیا تو از ایران هستی؟  

<br>

B: Yes, I'm from Iran. And you? Are you from Iran, too?  
B: بله، من از ایران هستم. و تو؟ آیا تو هم از ایران هستی؟  

<br>

A: No, I'm not from Iran. I'm from Canada.  
A: نه، من از ایران نیستم. من از کانادا هستم.  

<br>

*****

hello  
سلام  


Hello, Jim.  
سلام، جیم.  


hello  
سلام  

How are you?  
حالت چطوره؟  

how  
چطور  

you  
تو  

You are.  
تو هستی.  

Are you?  
آیا تو هستی؟  

How are you?  
حالت چطوره؟  

I  
من  

am  
هستم  

I am.  
من هستم.  

You are.  
تو هستی.  

Hello. How are you?  
سلام. حالت چطوره؟  

I am.  
من هستم.  

fine  
خوب  

I am fine.  
حالم خوب است.  

I am.  
من هستم.  

I'm.  
من هستم.  

I am. I'm.  
من هستم. من هستم.  

I'm fine.  
حالم خوبه.  

thanks  
ممنون  

Hello, Joe.  
سلام، جو.  

How are you?  
حالت چطوره؟  

I'm fine, thanks.  
حالم خوبه، ممنون.  

from  
از  

Iran  
ایران  

from Iran  
از ایران  

You are.  
تو هستی.  

You are from Iran.  
تو از ایران هستی.  

Are you from Iran?  
آیا تو از ایران هستی؟  

You are from Iran.  
تو از ایران هستی.  

I am.  
من هستم.  

I am from Iran.  
من از ایران هستم.  

I'm from Iran.  
من از ایران هستم.  

yes  
بله  

Are you from Iran?  
آیا تو از ایران هستی؟  

Yes, I'm from Iran.  
بله، من از ایران هستم.  

and  
و  

Yes, I'm from Iran.  
بله، من از ایران هستم.  

and you?  
و تو؟  

and  
و  

Hello. how are you?  
سلام. حالت چطوره؟  

I'm fine, thanks.  
حالم خوبه، ممنون.  

and you?  
و تو؟  

too  
هم  

I'm fine, too.  
من هم خوب هستم.  

I'm from Iran, too.  
من هم از ایران هستم.  

Are you from Iran?  
آیا تو از ایران هستی؟  

Are you from Iran, too?  
آیا تو هم از ایران هستی؟  

no  
نه  

Are you from Iran?  
آیا تو از ایران هستی؟  

no  
نه  

I'm not.  
من نیستم.  

I'm not from Iran.  
من از ایران نیستم.  

Are you from Iran, too?  
آیا تو هم از ایران هستی؟  

No, I'm not from Iran.  
نه، من از ایران نیستم.  

Canada  
کانادا  

I'm from Iran.  
من از ایران هستم.  

I'm from Canada.  
من از کانادا هستم.  

I'm from Canada, too.  
من هم از کانادا هستم.  

Hello. How are you?  
سلام. حالت چطوره؟  

I'm fine, thanks.  
حالم خوبه، ممنون.  

Are you from Iran?  
آیا تو از ایران هستی؟  

Yes, I'm from Iran.  
بله، من از ایران هستم.  

and you?  
و تو؟  

Are you from Iran, too?  
آیا تو هم از ایران هستی؟  

No, I'm not from Iran.  
نه، من از ایران نیستم.  

I'm from Canada.  
من از کانادا هستم.  

******

hello  
سلام  

how  
چطور  

thanks  
ممنون  

from  
از  

Iran  
ایران  

Canada  
کانادا  

You are.  
تو هستی.  

You're.  
تو هستی.  

*****

You are from Canada.  
تو از کانادا هستی.  

You are.  
تو هستی.  

You're.  
تو هستی.  

You are.  
تو هستی.  

You're.  
تو هستی.  

You're from Canada.  
تو از کانادا هستی.  

hello  
سلام  

Are you from Iran?  
آیا تو از ایران هستی؟  

How are you?  
حالت چطوره؟  

Hello. how are you?  
سلام. حالت چطوره؟  

I'm fine.  
حالم خوبه.  

hello  
سلام  

How are you?  
حالت چطوره؟  

I'm fine.  
حالم خوبه.  

Are you from Canada?  
آیا تو از کانادا هستی؟  

Yes, I am.  
بله، من هستم.  

Are you from Canada, too?  
آیا تو هم از کانادا هستی؟  

No, I'm from Iran.  
نه، من از ایران هستم.  

I'm not from Canada.  
من از کانادا نیستم.  

Are you from Iran, too?  
آیا تو هم از ایران هستی؟  

No, I'm from Canada.  
نه، من از کانادا هستم.  

You're from Iran, too.  
تو هم از ایران هستی.  

hello  
سلام  

How are you?  
حالت چطوره؟  

I'm fine, thanks.  
حالم خوبه، ممنون.  

Are you from Iran?  
آیا تو از ایران هستی؟  

Yes, I'm from Iran. And you? Are you from Iran, too?  
بله، من از ایران هستم. و تو؟ آیا تو هم از ایران هستی؟  

No, I'm not from Iran. I'm from Canada  
نه، من از ایران نیستم. من از کانادا هستم.  

hello  
سلام  

hello  
سلام  

How are you?  
حالت چطوره؟  

I'm fine, thanks.  
حالم خوبه، ممنون.  

Are you from Iran?  
آیا تو از ایران هستی؟  

Yes, I'm from Iran.  
بله، من از ایران هستم.  

and you?  
و تو؟  

Are you from Iran, too?  
آیا تو هم از ایران هستی؟  


No, I'm not from Iran. I'm from Canada.  
نه، من از ایران نیستم. من از کانادا هستم.  

*****

A: Hello.  
A: سلام.  

<br>

B: Hello.  
B: سلام.  

<br>

A: How are you?  
A: حالت چطوره؟  

<br>

B: I'm fine, thanks.  
B: حالم خوبه، ممنون.  

<br>

A: Are you from Iran?  
A: آیا تو از ایران هستی؟  

<br>

B: Yes, I'm from Iran. And you? Are you from Iran, too?  
B: بله، من از ایران هستم. و تو؟ آیا تو هم از ایران هستی؟  

<br>

A: No, I'm not from Iran. I'm from Canada.  
A: نه، من از ایران نیستم. من از کانادا هستم.  

<br>

****

## پایان درس اول
