## درس هشتم آموزش زبان انگلیسی نصرت

<br><br>  


supermarket  
سوپرمارکت  

I want to buy a car.
می‌خواهم یک ماشین بخرم.

your car
ماشین شما

Where's your house?
خانه شما کجاست؟

I have a car.
من یک ماشین دارم.

Do you have tea?
آیا چای دارید؟

We don't have a house.
ما خانه‌ای نداریم.

Is your son home?
پسرتان خانه هست؟

but
اما

but not today
اما امروز نه

We have three cars.
ما سه ماشین داریم.

We have four sons.
ما چهار پسر داریم.

Excuse me, sir. Where is the mall?
ببخشید آقا، مرکز خرید کجاست؟

Excuse me, ma'am. Are you from Iran?
ببخشید خانم، آیا شما از ایران هستید؟

___

It's very far.
بسیار دور است.

It's not very far.
بسیار دور نیست.

Do you want to drink something?
آیا می‌خواهید چیزی بنوشید؟

No, thanks.
نه، ممنون.

No, thank you. I'm fine.
نه، متشکرم. حالم خوب است.

Yes, please.
بله، لطفاً.

Yes, some Coke, please.
بله، لطفاً کوکا کولا.

or some Pepsi
یا پپسی

one Coke
یک کوکا کولا

two Pepsis
دو پپسی

I want to drink some soda.
می‌خواهم نوشابه‌ای بنوشم.

me too
من هم

a restaurant
یک رستوران

a Persian restaurant
یک رستوران ایرانی

the Persian restaurant
رستوران ایرانی

The Persian restaurant is very far.
رستوران ایرانی بسیار دور است.

The Persian restaurant's very far.
رستوران ایرانی بسیار دور است.

from here
از اینجا

The Persian restaurant is very far from here.
رستوران ایرانی از اینجا بسیار دور است.

We're at the restaurant now.
ما همین الان در رستوران هستیم.

Where are you?
شما کجا هستید؟

We're at a restaurant, too.
ما هم در یک رستوران هستیم.

I don't want to drink anything.
من نمی‌خواهم چیزی بنوشم.

two Pepsis, please
لطفاً دو پپسی

I know a Persian restaurant.
من یک رستوران ایرانی می‌شناسم.

Where's the Persian restaurant?
رستوران ایرانی کجاست؟

Where is it?
کجاست؟

It's not very far from here.
از اینجا بسیار دور نیست.

two coffees
دو قهوه

two restaurants
دو رستوران

I know two Persian restaurants.
من دو رستوران ایرانی می‌شناسم.

Do you live in Iran?
آیا شما در ایران زندگی می‌کنید؟

Yes, I live there.
بله، من آنجا زندگی می‌کنم.

What do you do there?
شما آنجا چه کار می‌کنید؟

I have a restaurant.
من یک رستوران دارم.

I have.
من دارم.

You have.
شما دارید.

Do you speak English?
آیا شما انگلیسی صحبت می‌کنید؟

Do you have tea?
آیا چای دارید؟

Yes, I have some tea.
بله، من چایی دارم.

We have some tea.
ما چایی داریم.

Can we go to the mall?
آیا می‌توانیم به مرکز خرید برویم؟

not today
امروز نه

Yes, but not today.
بله، اما امروز نه.

but not today
اما امروز نه

but
اما

not now
الان نه

but not now
اما الان نه

I want to drink something.
می‌خواهم چیزی بنوشم.

but not coffee
اما نه قهوه

Do you want Pepsi or Coke?
آیا می‌خواهید پپسی یا کوکا کولا؟

I want two Pepsis and one Coke.
من می‌خواهم دو پپسی و یک کوکا کولا.

I want to buy some tea.
می‌خواهم چایی بخرم.

Where do you want to buy some tea?
شما می‌خواهید کجا چای بخرید؟

at a supermarket
در یک سوپرمارکت

I'm going to the supermarket now.
من همین الان به سوپرمارکت می‌روم.

store
فروشگاه

mall
مرکز خرید

The supermarket is very far.
سوپرمارکت بسیار دور است.

But you have a car.
اما شما ماشین دارید.

car
ماشین

a car
یک ماشین

two Pepsis
دو پپسی

two cars
دو ماشین

We have two cars.
ما دو ماشین داریم.

But you have one car.
اما شما یک ماشین دارید.

Do you have a car?
آیا شما ماشین دارید؟

Yes, I have a car.
بله، من یک ماشین دارم.

I have a house, too.
من هم یک خانه دارم.

house
خانه

I have one house and two cars.
من یک خانه و دو ماشین دارم.

We have a house.
ما یک خانه داریم.

Do you have a house?
آیا شما خانه دارید؟

Yes, I have a house.
بله، من یک خانه دارم.

Where's your house?
خانه شما کجاست؟

your house
خانه شما

your car
ماشین شما

Where's Farhad?
فرهاد کجاست؟

Where's your car?
ماشین شما کجاست؟

It's there.
آنجاست.

Your house is here.
خانه شما اینجاست.

Is your house here?
خانه شما اینجاست؟

No, it's not here.
نه، اینجا نیست.

Yes, it's here.
بله، اینجاست.

Is it here or there?
آیا اینجاست یا آنجا؟

It's not here.
اینجا نیست.

I want to buy a car.
می‌خواهم یک ماشین بخرم.

but not now
اما الان نه

We don't want.
ما نمی‌خواهیم.

We don't want to buy a house.
ما نمی‌خواهیم خانه بخریم.  


We don't want to buy a house now.
ما همین الان نمی‌خواهیم خانه بخریم.  


Shadi, where's your house?
شادی، خانه شما کجاست؟  


It's there.
آنجاست.

I want to drink something.
می‌خواهم چیزی بنوشم.

What do you want to drink?
چه چیزی می‌خواهید بنوشید؟

What do you want to have?
چه چیزی می‌خواهید داشته باشید؟

tea or coffee?
چای یا قهوه؟

I'm fine.
حالم خوب است.

Tea's fine.
چای خوب است.

Do you want coffee or tea?
آیا می‌خواهید قهوه یا چای؟

Coffee's fine.
قهوه خوب است.

I want to go to the supermarket.
می‌خواهم به سوپرمارکت بروم.  


when?
کی؟

today
امروز

We want to go to Florida today.
ما می‌خواهیم امروز به فلوریدا برویم.

to Iran
به ایران

to a supermarket
به یک سوپرمارکت

What do you want to do?
شما چه می‌خواهید انجام دهید؟

I want to go to a restaurant.
می‌خواهم به یک رستوران بروم.

where?
کجا؟

to a restaurant
به یک رستوران

to a Persian restaurant
به یک رستوران ایرانی

I want to buy something at a supermarket.
می‌خواهم چیزی را در یک سوپرمارکت بخرم.

Where do you buy your tea?
شما چای خود را کجا می‌خرید؟

at a supermarket
در یک سوپرمارکت

Where are you from?
شما از کجا هستید؟

Where do you buy tea from?
شما چای را از کجا می‌خرید؟

from the store
از فروشگاه

at the store
در فروشگاه

Can I buy something, too?
آیا من هم می‌توانم چیزی بخرم؟

No, you can't.
نه، شما نمی‌توانید.

Yes, you can.
بله، شما می‌توانید.

______

A: Jim, what do you want to drink?
جیم، چه چیزی می‌خواهید بنوشید؟

B: I don't know. What do you have?
من نمی‌دانم. شما چه چیزی دارید؟

A: I have tea, coffee, and Coke.
من چای، قهوه و کوکا کولا دارم.

B: Tea's fine, but coffee's better. I want some coffee.
چای خوب است، اما قهوه بهتر است. من می‌خواهم قهوه.

A: Jim, when do you want to buy a car?
جیم، کی می‌خواهید ماشین بخرید؟

B: I don't know.
من نمی‌دانم.

A: Where's your house? Is your house very far from here?
خانه شما کجاست؟ خانه شما از اینجا بسیار دور است؟  

B: No, it's not very far from here. Sarah, do you know Mina?  

نه، از اینجا بسیار دور نیست. سارا، آیا شما مینا را می‌شناسید؟

A: Yes, I know Mina.
بله، من مینا را می‌شناسم.

B: Where's Mina from?
مینا از کجاست؟

A: I think Mina's from Iran.
من فکر می‌کنم مینا از ایران است.

B: I want to go to a supermarket now. I want to buy something.
من می‌خواهم همین الان به سوپرمارکت بروم. من می‌خواهم چیزی بخرم.

A: Are you going now?
شما همین الان می‌روید؟

B: Yes, I'm going now. Thank you, Sarah.
بله، من همین الان می‌روم. متشکرم، سارا.

A: You're welcome Jim. Goodbye.
خوش آمدید جیم. خداحافظ.

B: Goodbye, Sarah.  
خداحافظ، سارا.  

We have a house in Iran.
ما یک خانه در ایران داریم.  


Do you have a car, too?
آیا شما هم ماشین دارید؟  


We have three cars.
ما سه ماشین داریم.

three
سه

three cars
سه ماشین

We have three cars.
ما سه ماشین داریم.

But you have two cars.
اما شما دو ماشین دارید.

three
سه

four
چهار

one
یک

two
دو

three
سه

four
چهار

I have four sons.
من چهار پسر دارم.

son
پسر

your son
پسر شما

We have three sons.
ما سه پسر داریم.

But we have one son.
اما ما یک پسر داریم.

Where's your son?
پسر شما کجاست؟

Is your son home?
پسر شما خانه هست؟

I don't know.
من نمی‌دانم.

Where's the mall?
مرکز خرید کجاست؟

excuse me
ببخشید

Excuse me. Where's the mall?
ببخشید. مرکز خرید کجاست؟

The mall's there.
مرکز خرید آنجاست.

The mall is there.
مرکز خرید آنجاست.

thank you
متشکرم

You're welcome.
خوش آمدید.

Excuse me. Where are you from?
ببخشید. شما از کجا هستید؟

Excuse me. Are you from Iran?
ببخشید. آیا شما از ایران هستید؟

No, I'm not from Iran.
نه، من از ایران نیستم.

Excuse me. Are you Omid?
ببخشید. آیا شما امید هستید؟

No, I'm Ali.
نه، من علی هستم.

Is Omid home?
امید خانه هست؟

No, Omid's not home.
نه، امید خانه نیست.

sir
آقا

Hello, sir.
سلام آقا.

Excuse me, sir.
ببخشید آقا.

Is the Persian restaurant here?
رستوران ایرانی اینجاست؟

Excuse me, sir. Is the Persian restaurant here?
ببخشید آقا. رستوران ایرانی اینجاست؟

I don't know.
من نمی‌دانم.

Yes, it's here.
بله، اینجاست.

No, it's there.
نه، آنجاست.

ma'am
خانم

No, ma'am.
نه، خانم.

Hello, ma'am.
سلام خانم.

Excuse me, ma'am. Are you from Canada?
ببخشید خانم. آیا شما از کانادا هستید؟

No, sir. I'm from Iran.
نه، آقا. من از ایران هستم.

me too
من هم

__

but
اما

We have.
ما داریم.

Hello, sir.
سلام آقا.

Hello, ma'am.
سلام خانم.

excuse me
ببخشید

three
سه

four
چهار

___

I have three sons.
من سه پسر دارم.

your sons
پسران شما

Do your sons live in Iran?
پسران شما در ایران زندگی می‌کنند؟

Do you want to go to a supermarket?
آیا می‌خواهید به سوپرمارکت بروید؟

Yes, but not now.
بله، اما الان نه.

but not today
اما امروز نه

Do you want to drink something?
آیا می‌خواهید چیزی بنوشید؟

No, I don't want anything. Thanks.
نه، من چیزی نمی‌خواهم. متشکرم.

Yes, some tea, please.
بله، لطفاً چایی.

or some coffee
یا قهوه‌ای

I have some Coke, too.
من هم کوکا کولایی دارم.

Tea's fine.
چای خوب است.

Where's your house?
خانه شما کجاست؟

It's far.
دور است.

It's not far.
دور نیست.

The supermarket is not far from here.
سوپرمارکت از اینجا دور نیست.

I think it's very far.
من فکر می‌کنم بسیار دور است.

I don't want to drink anything now.
من الان نمی‌خواهم چیزی بنوشم.

three
سه

four
چهار

Do you have a car?
آیا شما ماشین دارید؟

No, I don't have a car. And you?
نه، من ماشین ندارم. و شما؟

We have two cars.
ما دو ماشین داریم



<br><br>

### پایان درس هشتم 
