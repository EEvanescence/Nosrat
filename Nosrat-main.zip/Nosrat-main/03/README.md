> [!NOTE]
> ### درس سوم آموزش زبان انگلیسی نصرت
>
> 

<br><br>  


***  


please  
لطفا  


I think.  
من فکر می‌کنم.  



I know.  
من می‌دانم.  


better  
بهتر  


better than  
بهتر از  


better than me  
بهتر از من  


better than you  
بهتر از تو  


some tea  
چایی  


Can you speak English?  
آیا می‌توانید انگلیسی صحبت کنید؟  


We're from Iran.  
ما از ایران هستیم.  


****  


tea  
چای  


a tea  
یک چای  


a coffee  
یک قهوه  


Hello. how are you?  
سلام. حالت چطوره؟  


Fine, thanks.  
خوب، ممنون.  


I'm fine, thank you.  
حالم خوبه، ممنون.  


You're welcome.  
خواهش می‌کنم.  


Do you speak English?  
آیا انگلیسی صحبت می‌کنید؟  


No, I don't speak English.  
نه، من انگلیسی صحبت نمی‌کنم.  


Yes, I speak English.  
بله، من انگلیسی صحبت می‌کنم.  


I can speak Persian, too.  
من هم می‌توانم فارسی صحبت کنم.  


Do you want a tea?  
آیا یک چای می‌خواهید؟  


No, thank you.  
نه، ممنون.  


No, thank you. I'm fine.  
نه، ممنون. حالم خوبه.  


I want coffee.  
من قهوه می‌خواهم.  


some  
یک مقدار  


tea  
چای  


some tea  
یک مقدار چای  


I want some tea.  
من یک مقدار چای می‌خواهم.  


some coffee  
یک مقدار قهوه  


Do you want some coffee?  
آیا یک مقدار قهوه می‌خواهید؟  


No, I want some tea.  
نه، من یک مقدار چای می‌خواهم.  


thank you  
ممنون  


thanks  
ممنون  


You're welcome.  
خواهش می‌کنم.  


I can speak English.  
من می‌توانم انگلیسی صحبت کنم.  


You are.  
تو هستی.  


Are you?  
آیا تو هستی؟  


You can.  
تو می‌توانی.  


Can you?  
آیا می‌توانی؟  


You can speak English.  
تو می‌توانی انگلیسی صحبت کنی.  


Can you speak English?  
آیا می‌توانی انگلیسی صحبت کنی؟  


Can you speak?  
آیا می‌توانی صحبت کنی؟  


Can you speak English?  
آیا می‌توانی انگلیسی صحبت کنی؟  


Yes, I can speak English.  
بله، من می‌توانم انگلیسی صحبت کنم.  


I can.  
من می‌توانم.  


Can I?  
آیا می‌توانم؟  


Can I speak Persian?  
آیا می‌توانم فارسی صحبت کنم؟  


Yes, you can speak Persian.  
بله، تو می‌توانی فارسی صحبت کنی.  


Yes, you can.  
بله، تو می‌توانی.  


Can I speak English?  
آیا می‌توانم انگلیسی صحبت کنم؟  


Yes, you can.  
بله، تو می‌توانی.  


Can you speak Persian, too?  
آیا تو هم می‌توانی فارسی صحبت کنی؟  


Yes, I can.  
بله، من می‌توانم.  


I'm not from Iran.  
من از ایران نیستم.  


I'm from Canada.  
من از کانادا هستم.  


I speak English.  
من انگلیسی صحبت می‌کنم.  


We are from Iran.  
ما از ایران هستیم.  


We are.  
ما هستیم.  

we  
ما  

We are from Iran.  
ما از ایران هستیم.  


I can.  
من می‌توانم.  


We can.  
ما می‌توانیم.  


We want.  
ما می‌خواهیم.  


You are.  
تو هستی.  


You're.  
تو هستی.  


We're.  
ما هستیم.  


We're from Iran.  
ما از ایران هستیم.  


We speak Persian.  
ما فارسی صحبت می‌کنیم.  


Wespeak English, too.  
ما هم انگلیسی صحبت می‌کنیم.  


We can Speak English, too.  
ما هم می‌توانیم انگلیسی صحبت کنیم.  


Are you from Canada?  
آیا تو از کانادا هستی؟  


Yes, we're from Canada.  
بله، ما از کانادا هستیم.  


You're not.  
تو نیستی.  


We're not.  
ما نیستیم.  


We're not from Canada.  
ما از کانادا نیستیم.  


We don't want tea.  
ما چای نمی‌خواهیم.  


We want coffee.  
ما قهوه می‌خواهیم.  


Do you want some tea?  
آیا یک مقدار چای می‌خواهید؟  


No, thanks.  
نه، ممنون.  


Yes, please.  
بله، لطفا.  


please  
لطفا  


Yes, please.  
بله، لطفا.  


Do you want some coffee?  
آیا یک مقدار قهوه می‌خواهید؟  


Yes, please.  
بله، لطفا.  


No, thanks.  
نه، ممنون.  


No, thank you. I'm fine.  
نه، ممنون. حالم خوبه.  


I can.  
من می‌توانم.  


You can.  
تو می‌توانی.  


better  
بهتر  


better than  
بهتر از  


I speak English.  
من انگلیسی صحبت می‌کنم.  


better than  
بهتر از  


better than you  
بهتر از تو  


I speak English better than you.  
من انگلیسی را بهتر از تو صحبت می‌کنم.  


I can speak English.  
من می‌توانم انگلیسی صحبت کنم.  


better than you  
بهتر از تو  


I can speak English better than you.  
من می‌توانم انگلیسی را بهتر از تو صحبت کنم.  


better  
بهتر  


better than you  
بهتر از تو  


better than me  
بهتر از من  


You speak better than me.  
تو بهتر از من صحبت می‌کنی.  


I don't speak English.  
من انگلیسی صحبت نمی‌کنم.  


better than you  
بهتر از تو  


You don't speak English.  
تو انگلیسی صحبت نمی‌کنی.  


better than me  
بهتر از من  


You don't speak English better than me.
تو انگلیسی را بهتر از من صحبت نمی‌کنی.  


better  
بهتر  


I speak better.  
من بهتر صحبت می‌کنم.  


I speak better than you.  
من بهتر از تو صحبت می‌کنم.  


I'm better than you.  
من از تو بهتر هستم.  


You're better than me.  
تو از من بهتر هستی.  


We're better than you.  
ما از تو بهتر هستیم.  


Hello. How are you?  
سلام. حالت چطوره؟  


Fine, thank you.  
خوب، ممنون.  

I speak.  
من صحبت می‌کنم.  

I think.  
من فکر می‌کنم.  

You're from Canada.  
تو از کانادا هستی.  

I think you're from Canada.  
من فکر می‌کنم تو از کانادا هستی.  

We think.  
ما فکر می‌کنیم.  

You think.  
تو فکر می‌کنی.  

You think we're from Iran.  
تو فکر می‌کنی ما از ایران هستیم.  

I think I want a tea.  
من فکر می‌کنم یک چای می‌خواهم.  

I don't speak.  
من صحبت نمی‌کنم.  

I don't think.  
من فکر نمی‌کنم.  

*****

A: Ali, do you want some coffee?  
A: علی، یک مقدار قهوه می‌خواهی؟  

B: No, thanks. I'm fine.  
B: نه، ممنون. حالم خوبه.  

<br>

A: Ali, can you speak English?  
A: علی، می‌توانی انگلیسی صحبت کنی؟  

B: Yes, I can speak English. I speak Persian, too.  
B: بله، من می‌توانم انگلیسی صحبت کنم. من هم فارسی صحبت می‌کنم.  

<br>

A: Ali, I don't think you speak Persian.  
A: علی، من فکر نمی‌کنم تو فارسی صحبت کنی.  

B: I can speak Persian. I'm from Iran. I speak Persian better than English.  
B: من می‌توانم فارسی صحبت کنم. من از ایران هستم. من فارسی را بهتر از انگلیسی صحبت می‌کنم.  

<br>

A: Ali, I think I speak English better than you, and you speak Persian better than me.  
A: علی، من فکر می‌کنم من انگلیسی را بهتر از تو صحبت می‌کنم، و تو فارسی را بهتر از من صحبت می‌کنی.  

B: I don't think you speak English better than me.  
B: من فکر نمی‌کنم تو انگلیسی را بهتر از من صحبت کنی.  

<br>

A: Do you think you speak English better than me?  
A: فکر می‌کنی انگلیسی را بهتر از من صحبت می‌کنی؟  

B: Yes, I think I speak better than you. I don't think you speak better than me.  
B: بله، من فکر می‌کنم بهتر از تو صحبت می‌کنم. من فکر نمی‌کنم تو بهتر از من صحبت کنی.  


****  


You speak English.  
تو انگلیسی صحبت می‌کنی.  


I don't think you speak English.  
من فکر نمی‌کنم تو انگلیسی صحبت کنی.  


We don't think you're from Canada.  
ما فکر نمی‌کنیم تو از کانادا هستی.  


We think you're from Iran.  
ما فکر می‌کنیم تو از ایران هستی.  


Do you want some tea?  
آیا یک مقدار چای می‌خواهی؟  


Do you think I'm from Canada?  
فکر می‌کنی من از کانادا هستم؟  


Yes, I think you're from Canada.  
بله، من فکر می‌کنم تو از کانادا هستی.  


No, I'm not from Canada.  
نه، من از کانادا نیستم.  


****

please  
لطفا  

think  
فکر کن  

than  
از  

better than  
بهتر از  

we  
ما  

We are.  
ما هستیم.  


****  


Know.  
می‌دانم.  


I think you speak better than me.  
من فکر می‌کنم تو بهتر از من صحبت می‌کنی.  


I know you speak better than me.  
من می‌دانم تو بهتر از من صحبت می‌کنی.  


We know you're from Iran.  
ما می‌دانیم تو از ایران هستی.  


Do you think we're from Canada?  
فکر می‌کنی ما از کانادا هستیم؟  


I think I know.  
من فکر می‌کنم می‌دانم.  


I think you know me.  
من فکر می‌کنم تو مرا می‌شناسی.  


I don't know you.  
من تو را نمی‌شناسم.  


Do I know you?  
آیا من تو را می‌شناسم؟  


Do you know me?  
آیا تو مرا می‌شناسی؟  


Idon't think I know you.  
من فکر نمی‌کنم تو را بشناسم.  


Do you think I know you?  
فکر می‌کنی من تو را می‌شناسم؟  


Yes, I think you know me.  
بله، من فکر می‌کنم تو مرا می‌شناسی.  


I think you can speak English.  
من فکر می‌کنم تو می‌توانی انگلیسی صحبت کنی.  


Can you speak Persian?  
آیا می‌توانی فارسی صحبت کنی؟  


Yes, I can.  
بله، می‌توانم.  


No, I don't speak Persian.  
نه، من فارسی صحبت نمی‌کنم.  


I know you speak Persian.  
من می‌دانم تو فارسی صحبت می‌کنی.  


I'm from Iran. And you?  
من از ایران هستم. و تو؟  


We're from Iran, too.  
ما هم از ایران هستیم.  


No, we're not from Iran.  
نه، ما از ایران نیستیم.  


better than  
بهتر از  


I speak Persian.  
من فارسی صحبت می‌کنم.  


better than English  
بهتر از انگلیسی  


I speak Persian better than English.  
من فارسی را بهتر از انگلیسی صحبت می‌کنم.  


We speak English better than Persian.  
ما انگلیسی را بهتر از فارسی صحبت می‌کنیم.  

Do you think you speak better than me?  
فکر می‌کنی بهتر از من صحبت می‌کنی؟  

I know I speak better than you.  
من می‌دانم بهتر از تو صحبت می‌کنم.  

Do you want some coffee?  
آیا یک مقدار قهوه می‌خواهی؟  

Yes, please.  
بله، لطفا.  

No, thanks.  
نه، ممنون.  

No, thank you. I'm fine.  
نه، ممنون. حالم خوبه.  

No, thanks.  
نه، ممنون.  

No, thanks. I'm fine.  
نه، ممنون. حالم خوبه.  

thank you  
ممنون  

You're welcome.  
خواهش می‌کنم.  

****

## پایان درس سوم
